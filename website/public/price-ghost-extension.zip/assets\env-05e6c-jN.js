const e="https://price-ghost.onrender.com/api".replace(/\/+$/,""),p="https://price-ghost.netlify.app".replace(/\/+$/,"");export{e as A,p as W};
