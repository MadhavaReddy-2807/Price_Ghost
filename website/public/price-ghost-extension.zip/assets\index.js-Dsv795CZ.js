import{W as Z,A as N}from"./env-C2N6tvkg.js";function E(e){if(!e)return 0;const t=String(e).replace(/,/g,"").replace(/[^0-9.]/g," ").trim().match(/(\d+(?:\.\d+)?)/);return t?parseFloat(t[1]):0}function Y(){var h,u,x,k;const e=window.location.href;let i="";const t=[/(?:dp|gp\/product|gp\/aw\/d|product|d)\/([A-Z0-9]{10})/i,/[?&]asin=([A-Z0-9]{10})/i,/\/([A-Z0-9]{10})(?:[/?#]|$)/i];for(const r of t){const d=e.match(r);if(d&&d[1]&&d[1].length===10){i=d[1].toUpperCase();break}}if(!i){const r=document.getElementById("ASIN")||document.querySelector('input[name="ASIN"]')||document.querySelector('input[name="asin"]')||document.getElementById("ftSelectAsin")||document.getElementById("deliveryBlockSelectAsin");r&&r.value&&/^[A-Z0-9]{10}$/i.test(r.value.trim())&&(i=r.value.trim().toUpperCase())}if(!i){const r=document.querySelector("[data-asin]");if(r){const d=r.getAttribute("data-asin");d&&/^[A-Z0-9]{10}$/i.test(d.trim())&&(i=d.trim().toUpperCase())}}if(!i){const r=(h=document.querySelector('link[rel="canonical"]'))==null?void 0:h.getAttribute("href");if(r){const d=r.match(/(?:dp|product)\/([A-Z0-9]{10})/i);d&&(i=d[1].toUpperCase())}}if(!i)return null;let a="",o="",n=0,c=0,s=!0;const p=document.querySelectorAll('script[type="application/ld+json"]');for(const r of p)try{const d=JSON.parse(r.textContent||r.innerText||"{}"),v=Array.isArray(d)?d:[d];for(const g of v)if(g["@type"]==="Product"&&(g.name&&(a=g.name),g.image&&(o=Array.isArray(g.image)?g.image[0]:g.image),g.offers)){const A=Array.isArray(g.offers)?g.offers[0]:g.offers;A.price&&(n=E(A.price))}}catch{}if(!a){const r=document.getElementById("productTitle")||document.querySelector("h1#title")||document.querySelector("#titleSection h1")||document.querySelector("#centerCol h1");r&&(a=(r.textContent||r.innerText||"").trim())}if(a||(a=((u=document.querySelector('meta[property="og:title"]'))==null?void 0:u.getAttribute("content"))||document.title.replace(/\s*:\s*Amazon.*$/i,"").trim()),!o){const r=document.getElementById("landingImage")||document.getElementById("imgBlkFront")||document.querySelector("#main-image-container img")||document.querySelector("#imgTagWrapperId img");if(o=(r==null?void 0:r.getAttribute("data-old-hires"))||(r==null?void 0:r.getAttribute("data-a-dynamic-image"))||(r==null?void 0:r.src)||"",o.startsWith("{"))try{const d=JSON.parse(o);o=Object.keys(d)[0]||""}catch{}}if(!n){const r=["#corePriceDisplay_desktop_feature_div .priceToPay .a-offscreen","#corePrice_desktop .priceToPay .a-offscreen","#corePriceDisplay_desktop_feature_div span.a-price-whole","#corePrice_desktop span.a-price-whole","#apex_desktop .priceToPay .a-offscreen","#apex_desktop .a-price .a-offscreen","#priceblock_dealprice","#priceblock_ourprice","#priceblock_saleprice","#price_inside_buybox","#newBuyBoxPrice",".priceToPay .a-offscreen","span.a-price.a-text-price.header-price .a-offscreen","span.a-price span.a-offscreen",".a-price.a-text-price .a-offscreen","span.a-price-whole","#price"];for(const d of r){const v=document.querySelector(d);if(v){const g=(v.textContent||v.innerText||"").trim();if(g){const A=E(g);if(A>0){n=A;break}}}}}if(!n){const r=((x=document.querySelector('meta[property="og:price:amount"]'))==null?void 0:x.getAttribute("content"))||((k=document.querySelector('meta[name="twitter:data1"]'))==null?void 0:k.getAttribute("content"));r&&(n=E(r))}const b=["#corePriceDisplay_desktop_feature_div .basisPrice .a-offscreen","#corePrice_desktop .basisPrice .a-offscreen",".basisPrice .a-offscreen",'span[data-a-strike="true"]',".a-price.a-text-price .a-offscreen","#listPrice"];for(const r of b){const d=document.querySelector(r);if(d){const v=(d.textContent||d.innerText||"").trim();if(v){const g=E(v);if(g>n){c=g;break}}}}c||(c=n);const l=document.getElementById("availability"),f=((l==null?void 0:l.textContent)||(l==null?void 0:l.innerText)||"").toLowerCase();return(f.includes("currently unavailable")||f.includes("out of stock"))&&(s=!1),n<=0?null:{platform:"amazon",externalId:i,title:a.replace(/\s+/g," ").trim(),url:window.location.origin+"/dp/"+i,imageUrl:o,currentPrice:n,mrpPrice:c,currency:"INR",inStock:s}}function C(e){if(!e)return 0;const t=String(e).replace(/,/g,"").replace(/[^0-9.]/g," ").trim().match(/(\d+(?:\.\d+)?)/);return t?parseFloat(t[1]):0}function J(){var h;const e=window.location.href;let i="";const t=e.match(/[?&]pid=([A-Z0-9]+)/i);if(t)i=t[1];else{const u=e.match(/\/p\/(itm[a-zA-Z0-9]+)/i);u&&(i=u[1])}if(!i)return null;let a="",o="",n=0,c=0,s=!0;const p=document.querySelectorAll('script[type="application/ld+json"]');for(const u of p)try{const x=JSON.parse(u.innerText||"{}"),k=Array.isArray(x)?x:[x];for(const r of k)if(r["@type"]==="Product"&&(r.name&&(a=r.name),r.image&&(o=Array.isArray(r.image)?r.image[0]:r.image),r.offers)){const d=Array.isArray(r.offers)?r.offers[0]:r.offers;d.price&&(n=C(d.price))}}catch{}if(!a){const u=document.querySelector("span.B_NuCI, h1._6EBuvd, h1.VU-ZEz, span._35KyD6, h1");a=((h=u==null?void 0:u.innerText)==null?void 0:h.trim())||document.title}if(!o){const u=document.querySelector("img._396cs4, img._2r_T1I, img.DByuf4, img._3kidjx");o=(u==null?void 0:u.src)||""}if(!n){const u=["div.Nx9daj div._30jeq3","div._30jeq3._16Jk6d","div._30jeq3","div.hl05eU div._30jeq3"];for(const x of u){const k=document.querySelector(x);if(k&&k.innerText){const r=C(k.innerText);if(r>0){n=r;break}}}}const b=["div.yRaY8j","div._3I9_wc._2p6lqe","div._3I9_wc","div.hl05eU div._3I9_wc"];for(const u of b){const x=document.querySelector(u);if(x&&x.innerText){const k=C(x.innerText);if(k>n){c=k;break}}}c||(c=n);const l=document.querySelector("div._16FRp0, ._2SmN8-"),f=document.body.innerText.toLowerCase();return(l||f.includes("sold out")||f.includes("currently out of stock"))&&(s=!1),n<=0?null:{platform:"flipkart",externalId:i,title:a,url:e,imageUrl:o,currentPrice:n,mrpPrice:c,currency:"INR",inStock:s}}function R(e){if(!e)return 0;const t=String(e).replace(/,/g,"").replace(/[^0-9.]/g," ").trim().match(/(\d+(?:\.\d+)?)/);return t?parseFloat(t[1]):0}function H(){var u,x,k,r,d;const e=window.location.href,i=e.match(/\/([0-9]{5,10})(?:\/buy)?(?:[?#]|$)/i);if(!i)return null;const t=i[1];let a="",o="",n=0,c=0,s=!0;const p=((x=(u=document.querySelector("h1.pdp-title"))==null?void 0:u.innerText)==null?void 0:x.trim())||"",b=((r=(k=document.querySelector("h1.pdp-name"))==null?void 0:k.innerText)==null?void 0:r.trim())||"";a=p?`${p} ${b}`:b||document.title;const l=document.querySelector("div.image-grid-image, img.image-grid-image");l&&(o=l.getAttribute("src")||"",!o&&((d=l.style)!=null&&d.backgroundImage)&&(o=l.style.backgroundImage.replace(/^url\(["']?/,"").replace(/["']?\)$/,"")));const f=document.querySelector("span.pdp-price strong, span.pdp-discounted-price, span.pdp-price");f&&f.innerText&&(n=R(f.innerText));const h=document.querySelector("span.pdp-mrp s, span.pdp-mrp");if(h&&h.innerText){const v=R(h.innerText);v>n&&(c=v)}return c||(c=n),n<=0?null:{platform:"myntra",externalId:t,title:a,url:e,imageUrl:o,currentPrice:n,mrpPrice:c,currency:"INR",inStock:s}}function V(e){let i=window.location.href,t=null;const a=()=>{clearTimeout(t),t=setTimeout(()=>{const s=window.location.href;s!==i&&(i=s,e())},600)},o=history.pushState;history.pushState=function(...s){o.apply(this,s),a()};const n=history.replaceState;history.replaceState=function(...s){n.apply(this,s),a()},window.addEventListener("popstate",a);const c=new MutationObserver(()=>{window.location.href!==i&&a()});document.body?c.observe(document.body,{childList:!0,subtree:!0}):document.addEventListener("DOMContentLoaded",()=>{c.observe(document.body,{childList:!0,subtree:!0})})}let P=null,y=null,m=null,$=!1,B=!1,T=10,I=!1,S="";function G(e,i){if(!e||e<=0)return 0;const t=e*(1-i/100);return Math.round(t*100)/100}function _(e){return!e&&e!==0?"₹0":"₹"+Number(e).toLocaleString("en-IN")}async function X(e){var i;return!e||typeof chrome>"u"||!((i=chrome.storage)!=null&&i.local)?{isTracked:!1,token:null,trackingInfo:null}:new Promise(t=>{chrome.storage.local.get(["token","trackedKeys","defaultThreshold","user"],a=>{const o=a.token,n=`${e.platform}:${e.externalId}`,s=(a.trackedKeys||{})[n]||null;t({isTracked:!!s,token:o,trackingInfo:s,defaultThreshold:a.defaultThreshold||10,user:a.user||null})})})}async function Q(e,i,t){var c,s;const a={...e,targetPercentageDrop:t,baseline:"initial"},o=await fetch(`${N}/items/track`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${i}`},body:JSON.stringify(a)});if(!o.ok){const p=await o.json().catch(()=>({}));throw new Error(p.error||`Failed with status ${o.status}`)}const n=await o.json();return typeof chrome<"u"&&((c=chrome.storage)!=null&&c.local)&&(chrome.storage.local.get(["trackedKeys"],p=>{var f,h;const b=p.trackedKeys||{},l=`${e.platform}:${e.externalId}`;b[l]={itemId:(f=n.item)==null?void 0:f._id,targetPercentageDrop:t,targetPrice:((h=n.tracking)==null?void 0:h.targetPrice)||G(e.currentPrice,t),baselinePrice:e.currentPrice,trackedAt:Date.now()},chrome.storage.local.set({trackedKeys:b})}),(s=chrome.runtime)!=null&&s.sendMessage&&chrome.runtime.sendMessage({type:"ITEM_TRACKED",payload:n}).catch(()=>{})),n}async function ee(e,i,t){var o,n;if(!(await fetch(`${N}/items/untrack/${e}`,{method:"DELETE",headers:{Authorization:`Bearer ${t}`}})).ok)throw new Error("Failed to untrack item");typeof chrome<"u"&&((o=chrome.storage)!=null&&o.local)&&(chrome.storage.local.get(["trackedKeys"],c=>{const s=c.trackedKeys||{},p=`${i.platform}:${i.externalId}`;delete s[p],chrome.storage.local.set({trackedKeys:s})}),(n=chrome.runtime)!=null&&n.sendMessage&&chrome.runtime.sendMessage({type:"REFRESH_BADGE"}).catch(()=>{}))}const U=`
  :host {
    all: initial;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    font-size: 13px;
    line-height: 1.4;
    color: #1e293b;
    box-sizing: border-box;
    z-index: 2147483647;
    position: fixed;
    bottom: 24px;
    right: 24px;
    pointer-events: auto;
  }

  *, *::before, *::after {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }

  /* Floating Pill */
  .pg-floating-pill {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 18px;
    border-radius: 9999px;
    background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
    color: #ffffff;
    font-weight: 600;
    font-size: 13px;
    box-shadow: 0 10px 25px -5px rgba(79, 70, 229, 0.4), 0 8px 10px -6px rgba(79, 70, 229, 0.3);
    cursor: pointer;
    border: 1px solid rgba(255, 255, 255, 0.2);
    transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
    user-select: none;
    outline: none;
  }

  .pg-floating-pill:hover {
    transform: translateY(-2px) scale(1.02);
    box-shadow: 0 14px 28px -5px rgba(79, 70, 229, 0.5), 0 10px 12px -6px rgba(79, 70, 229, 0.4);
  }

  .pg-floating-pill.tracked {
    background: linear-gradient(135deg, #059669 0%, #10b981 100%);
    box-shadow: 0 10px 25px -5px rgba(16, 185, 129, 0.4), 0 8px 10px -6px rgba(16, 185, 129, 0.3);
  }

  .pg-ghost-icon {
    font-size: 16px;
    line-height: 1;
    filter: drop-shadow(0 1px 2px rgba(0, 0, 0, 0.2));
  }

  .pg-price-tag {
    background: rgba(255, 255, 255, 0.2);
    padding: 2px 8px;
    border-radius: 9999px;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: -0.01em;
  }

  .pg-min-toggle {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 18px;
    height: 18px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.2);
    font-size: 11px;
    margin-left: 2px;
    opacity: 0.7;
    transition: opacity 0.15s;
  }
  .pg-min-toggle:hover {
    opacity: 1;
    background: rgba(255, 255, 255, 0.35);
  }

  /* Minimized Bubble */
  .pg-bubble-minimized {
    width: 46px;
    height: 46px;
    border-radius: 50%;
    background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    box-shadow: 0 8px 20px rgba(79, 70, 229, 0.4);
    cursor: pointer;
    border: 2px solid white;
    transition: transform 0.2s;
  }
  .pg-bubble-minimized:hover {
    transform: scale(1.1);
  }

  /* Popover Card */
  .pg-card {
    position: absolute;
    bottom: 58px;
    right: 0;
    width: 325px;
    background: #ffffff;
    border-radius: 16px;
    box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.22), 0 0 0 1px rgba(0, 0, 0, 0.06);
    overflow: hidden;
    animation: pgSlideUp 0.25s cubic-bezier(0.16, 1, 0.3, 1);
  }

  @keyframes pgSlideUp {
    from {
      opacity: 0;
      transform: translateY(12px) scale(0.97);
    }
    to {
      opacity: 1;
      transform: translateY(0) scale(1);
    }
  }

  .pg-card-header {
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    padding: 12px 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #e2e8f0;
  }

  .pg-brand {
    display: flex;
    align-items: center;
    gap: 6px;
    font-weight: 700;
    font-size: 13px;
    color: #1e293b;
  }

  .pg-platform-pill {
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    padding: 2px 6px;
    border-radius: 4px;
    background: #e0e7ff;
    color: #4338ca;
  }

  .pg-close-btn {
    background: transparent;
    border: none;
    color: #94a3b8;
    font-size: 16px;
    cursor: pointer;
    line-height: 1;
    padding: 4px;
    border-radius: 4px;
  }
  .pg-close-btn:hover {
    color: #475569;
    background: #e2e8f0;
  }

  .pg-card-body {
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .pg-prod-title {
    font-size: 12px;
    font-weight: 600;
    color: #0f172a;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    line-height: 1.35;
  }

  .pg-price-row {
    display: flex;
    align-items: baseline;
    gap: 8px;
  }

  .pg-current-price {
    font-size: 18px;
    font-weight: 800;
    color: #4f46e5;
  }

  .pg-mrp-price {
    font-size: 12px;
    color: #94a3b8;
    text-decoration: line-through;
  }

  .pg-section-label {
    font-size: 11px;
    font-weight: 600;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.03em;
  }

  .pg-threshold-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 6px;
  }

  .pg-thresh-btn {
    padding: 6px 0;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
    background: #ffffff;
    font-size: 12px;
    font-weight: 600;
    color: #475569;
    cursor: pointer;
    transition: all 0.15s;
    text-align: center;
  }

  .pg-thresh-btn:hover {
    border-color: #cbd5e1;
    background: #f8fafc;
  }

  .pg-thresh-btn.active {
    border-color: #4f46e5;
    background: #eef2ff;
    color: #4f46e5;
    font-weight: 700;
  }

  .pg-slider-wrap {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .pg-range-input {
    flex: 1;
    accent-color: #4f46e5;
    cursor: pointer;
  }

  .pg-target-box {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 10px;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .pg-target-title {
    font-size: 11px;
    color: #64748b;
  }

  .pg-target-price {
    font-size: 14px;
    font-weight: 800;
    color: #059669;
  }

  .pg-action-btn {
    width: 100%;
    padding: 11px;
    border-radius: 10px;
    border: none;
    background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
    color: white;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
    transition: all 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
  }

  .pg-action-btn:hover {
    box-shadow: 0 6px 16px rgba(79, 70, 229, 0.4);
    filter: brightness(1.05);
  }

  .pg-action-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  .pg-btn-danger {
    background: #fee2e2;
    color: #b91c1c;
    border: 1px solid #fecaca;
    padding: 8px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    width: 100%;
    transition: background 0.15s;
  }
  .pg-btn-danger:hover {
    background: #fecaca;
  }

  .pg-status-banner {
    padding: 8px 12px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    text-align: center;
  }

  .pg-status-banner.success {
    background: #ecfdf5;
    color: #065f46;
    border: 1px solid #a7f3d0;
  }

  .pg-status-banner.error {
    background: #fef2f2;
    color: #991b1b;
    border: 1px solid #fecaca;
  }
`;async function w(){var l;if(!y||!m)return;const{isTracked:e,token:i,trackingInfo:t,defaultThreshold:a,user:o}=await X(m);if(B){y.innerHTML=`
      <style>${U}</style>
      <div class="pg-bubble-minimized" title="Price Ghost — Click to expand">
        👻
      </div>
    `,(l=y.querySelector(".pg-bubble-minimized"))==null||l.addEventListener("click",()=>{B=!1,w()});return}const n=_(m.currentPrice),c=G(m.currentPrice,T),s=m.currentPrice-c,p=e?`Tracked (-${(t==null?void 0:t.targetPercentageDrop)||10}%)`:"Track Price",b=`
    <style>${U}</style>

    ${$?`
      <div class="pg-card">
        <div class="pg-card-header">
          <div class="pg-brand">
            <span>👻</span>
            <span>Price Ghost</span>
            <span class="pg-platform-pill">${m.platform}</span>
          </div>
          <button class="pg-close-btn" id="pg-card-close" title="Close">✕</button>
        </div>

        <div class="pg-card-body">
          <p class="pg-prod-title" title="${m.title}">
            ${m.title}
          </p>

          <div class="pg-price-row">
            <span class="pg-current-price">${n}</span>
            ${m.mrpPrice&&m.mrpPrice>m.currentPrice?`<span class="pg-mrp-price">${_(m.mrpPrice)}</span>`:""}
          </div>

          ${S?`<div class="pg-status-banner ${S.type}">${S.text}</div>`:""}

          ${i?e?`
            <div style="padding: 12px; background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 10px;">
              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
                <span style="font-size: 12px; font-weight: 700; color: #065f46;">
                  Currently Monitored
                </span>
                <span style="font-size: 11px; font-weight: 700; color: #059669; background: #d1fae5; padding: 2px 6px; border-radius: 4px;">
                  -${(t==null?void 0:t.targetPercentageDrop)||10}% Target
                </span>
              </div>
              <p style="font-size: 11px; color: #047857;">
                Alert Price: <strong>${_((t==null?void 0:t.targetPrice)||c)}</strong>
              </p>
            </div>

            <div style="display: flex; gap: 8px; margin-top: 4px;">
              <button id="pg-untrack-btn" class="pg-btn-danger">
                Remove from Tracking
              </button>
            </div>
            `:`
            <div>
              <span class="pg-section-label">Alert me when price drops by:</span>
              <div class="pg-threshold-grid" style="margin-top: 6px; margin-bottom: 8px;">
                ${[5,10,15,20].map(f=>`
                  <button class="pg-thresh-btn ${T===f?"active":""}" data-pct="${f}">
                    ${f}%
                  </button>
                `).join("")}
              </div>

              <div class="pg-slider-wrap">
                <input
                  type="range"
                  id="pg-thresh-slider"
                  class="pg-range-input"
                  min="1"
                  max="90"
                  value="${T}"
                />
                <span style="font-size: 12px; font-weight: 800; color: #4f46e5; width: 32px; text-align: right;">
                  ${T}%
                </span>
              </div>
            </div>

            <div class="pg-target-box">
              <div>
                <p class="pg-target-title">Notify below</p>
                <p class="pg-target-price">${_(c)}</p>
              </div>
              <div style="text-align: right;">
                <p class="pg-target-title">You Save</p>
                <p style="font-size: 12px; font-weight: 700; color: #4f46e5;">${_(s)}</p>
              </div>
            </div>

            <button id="pg-track-submit" class="pg-action-btn" ${I?"disabled":""}>
              ${I?"Activating Tracker...":"👻 Track This Product"}
            </button>
            `:`
            <div style="padding: 12px; background: #fffbeb; border: 1px solid #fef3c7; border-radius: 10px; text-align: center;">
              <p style="font-size: 12px; color: #92400e; font-weight: 600; margin-bottom: 8px;">
                Sign in to track price drops!
              </p>
              <p style="font-size: 11px; color: #b45309; margin-bottom: 10px;">
                Connect Price Ghost to receive email alerts when this item's price falls.
              </p>
              <button id="pg-open-dashboard" class="pg-action-btn" style="font-size: 12px; padding: 8px;">
                Open Price Ghost Dashboard →
              </button>
            </div>
            `}
        </div>
      </div>
    `:""}

    <div class="pg-floating-pill ${e?"tracked":""}" id="pg-pill-btn">
      <span class="pg-ghost-icon">${e?"✓":"👻"}</span>
      <span>${p}</span>
      <span class="pg-price-tag">${n}</span>
      <span class="pg-min-toggle" id="pg-min-btn" title="Minimize">−</span>
    </div>
  `;y.innerHTML=b,te(i,e,t)}function te(e,i,t){var a,o,n,c,s,p,b;y&&((a=y.querySelector("#pg-pill-btn"))==null||a.addEventListener("click",l=>{l.target.closest("#pg-min-btn")||($=!$,S="",w())}),(o=y.querySelector("#pg-min-btn"))==null||o.addEventListener("click",l=>{l.stopPropagation(),B=!0,$=!1,w()}),(n=y.querySelector("#pg-card-close"))==null||n.addEventListener("click",()=>{$=!1,S="",w()}),(c=y.querySelector("#pg-open-dashboard"))==null||c.addEventListener("click",()=>{window.open(`${Z}/dashboard`,"_blank")}),y.querySelectorAll(".pg-thresh-btn").forEach(l=>{l.addEventListener("click",()=>{T=Number(l.getAttribute("data-pct")),w()})}),(s=y.querySelector("#pg-thresh-slider"))==null||s.addEventListener("input",l=>{T=Number(l.target.value),w()}),(p=y.querySelector("#pg-track-submit"))==null||p.addEventListener("click",async()=>{if(!(!m||!e)){I=!0,S="",w();try{await Q(m,e,T),S={type:"success",text:`🎉 Price tracker set for -${T}% drop!`},setTimeout(()=>{$=!1,w()},2e3)}catch(l){S={type:"error",text:l.message||"Failed to track product."}}finally{I=!1,w()}}}),(b=y.querySelector("#pg-untrack-btn"))==null||b.addEventListener("click",async()=>{if(!(!(t!=null&&t.itemId)||!e)&&confirm("Stop tracking this product?"))try{await ee(t.itemId,m,e),S={type:"success",text:"Product removed from tracking."},setTimeout(()=>{$=!1,w()},1500)}catch(l){alert("Failed to untrack: "+l.message)}}))}function D(e){if(!e||!e.externalId||e.currentPrice<=0){W();return}m=e,P||(P=document.createElement("div"),P.id="price-ghost-extension-root",y=P.attachShadow({mode:"open"}),document.documentElement.appendChild(P)),w()}function W(){P&&P.parentNode&&P.parentNode.removeChild(P),P=null,y=null,m=null}function z(){const e=window.location.hostname;return e.includes("amazon.")?Y():e.includes("flipkart.")?J():e.includes("myntra.")?H():null}let M=null,q=0;const re=6,ne=[500,1200,2500,4e3,6e3,9e3];async function oe(e,i,t){var a,o,n;try{const c={...e,targetPercentageDrop:t||10,baseline:"initial"};console.log(`[Price Ghost] 🚀 Sending manual track request for "${e.title}"...`);const s=await fetch(`${N}/items/track`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${i}`},body:JSON.stringify(c)});if(s.ok){const p=await s.json();return console.log("[Price Ghost] 👻 Tracked product successfully:",((a=p.item)==null?void 0:a.title)||e.title),typeof chrome<"u"&&((o=chrome.storage)!=null&&o.local)&&chrome.storage.local.get(["trackedKeys"],b=>{var h;const l=b.trackedKeys||{},f=`${e.platform}:${e.externalId}`;l[f]={itemId:(h=p.item)==null?void 0:h._id,targetPercentageDrop:t||10,trackedAt:Date.now()},chrome.storage.local.set({trackedKeys:l})}),typeof chrome<"u"&&((n=chrome.runtime)!=null&&n.sendMessage)&&chrome.runtime.sendMessage({type:"ITEM_TRACKED",payload:p}).catch(()=>{}),!0}else{const p=await s.text();return console.warn("[Price Ghost] Backend returned status:",s.status,p),!1}}catch(c){return console.warn("[Price Ghost] Backend connection error:",c.message),!1}}async function j(){var i;const e=z();if(!e||!e.externalId||e.currentPrice<=0){if(q<re){const t=ne[q]||2e3;q++,clearTimeout(M),M=setTimeout(j,t)}else W();return}`${e.platform}${e.externalId}`,typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local)&&chrome.storage.local.set({lastSeenProduct:{...e,detectedAt:Date.now()}}),console.log(`[Price Ghost] 🎯 Detected ${e.platform} product: "${e.title}" @ ₹${e.currentPrice}`),D(e)}function L(){q=0,clearTimeout(M),j()}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{L()}):L();V(()=>{L()});let O=null;const ie=new MutationObserver(()=>{clearTimeout(O),O=setTimeout(()=>{j()},1e3)}),K=document.body||document.documentElement;K&&ie.observe(K,{childList:!0,subtree:!0});var F;typeof chrome<"u"&&((F=chrome.runtime)!=null&&F.onMessage)&&chrome.runtime.onMessage.addListener((e,i,t)=>{var a;if(e.type==="GET_PAGE_PRODUCT"){const o=z();t({product:o})}else if(e.type==="REFRESH_PAGE_BUTTON"||e.type==="ITEM_TRACKED"){const o=z();o&&D(o),t({updated:!0})}else if(e.type==="FORCE_TRACK_PAGE"){const o=z();return o&&o.currentPrice>0?(a=chrome.storage)!=null&&a.local&&chrome.storage.local.get(["token","defaultThreshold"],async n=>{if(n.token){const c=e.targetPercentageDrop||n.defaultThreshold||10,s=await oe(o,n.token,c);s&&D(o),t({success:s,product:o})}else t({success:!1,error:"Not logged in"})}):t({success:!1,error:"Could not extract product details"}),!0}});
