const t="http://localhost:5000/api".replace(/\/+$/,""),a="http://localhost:5173".replace(/\/+$/,"");export{t as A,a as W};
