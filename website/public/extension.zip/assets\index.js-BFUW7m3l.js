import{W as Z,A as N}from"./env-05e6c-jN.js";function _(e){if(!e)return 0;const r=String(e).replace(/,/g,"").replace(/[^0-9.]/g," ").trim().match(/(\d+(?:\.\d+)?)/);return r?parseFloat(r[1]):0}function Y(){var m,f,h,b;const e=window.location.href;let o="";const r=[/(?:dp|gp\/product|gp\/aw\/d|product|d)\/([A-Z0-9]{10})/i,/[?&]asin=([A-Z0-9]{10})/i,/\/([A-Z0-9]{10})(?:[/?#]|$)/i];for(const t of r){const d=e.match(t);if(d&&d[1]&&d[1].length===10){o=d[1].toUpperCase();break}}if(!o){const t=document.getElementById("ASIN")||document.querySelector('input[name="ASIN"]')||document.querySelector('input[name="asin"]')||document.getElementById("ftSelectAsin")||document.getElementById("deliveryBlockSelectAsin");t&&t.value&&/^[A-Z0-9]{10}$/i.test(t.value.trim())&&(o=t.value.trim().toUpperCase())}if(!o){const t=document.querySelector("[data-asin]");if(t){const d=t.getAttribute("data-asin");d&&/^[A-Z0-9]{10}$/i.test(d.trim())&&(o=d.trim().toUpperCase())}}if(!o){const t=(m=document.querySelector('link[rel="canonical"]'))==null?void 0:m.getAttribute("href");if(t){const d=t.match(/(?:dp|product)\/([A-Z0-9]{10})/i);d&&(o=d[1].toUpperCase())}}if(!o)return null;let c="",a="",i=0,s=0,l=!0;const g=document.querySelectorAll('script[type="application/ld+json"]');for(const t of g)try{const d=JSON.parse(t.textContent||t.innerText||"{}"),w=Array.isArray(d)?d:[d];for(const y of w)if(y["@type"]==="Product"&&(y.name&&(c=y.name),y.image&&(a=Array.isArray(y.image)?y.image[0]:y.image),y.offers)){const $=Array.isArray(y.offers)?y.offers[0]:y.offers;$.price&&(i=_($.price))}}catch{}if(!c){const t=document.getElementById("productTitle")||document.querySelector("h1#title")||document.querySelector("#titleSection h1")||document.querySelector("#centerCol h1");t&&(c=(t.textContent||t.innerText||"").trim())}if(c||(c=((f=document.querySelector('meta[property="og:title"]'))==null?void 0:f.getAttribute("content"))||document.title.replace(/\s*:\s*Amazon.*$/i,"").trim()),!a){const t=document.getElementById("landingImage")||document.getElementById("imgBlkFront")||document.querySelector("#main-image-container img")||document.querySelector("#imgTagWrapperId img");if(a=(t==null?void 0:t.getAttribute("data-old-hires"))||(t==null?void 0:t.getAttribute("data-a-dynamic-image"))||(t==null?void 0:t.src)||"",a.startsWith("{"))try{const d=JSON.parse(a);a=Object.keys(d)[0]||""}catch{}}if(!i){const t=["#corePriceDisplay_desktop_feature_div .priceToPay .a-offscreen","#corePrice_desktop .priceToPay .a-offscreen","#corePriceDisplay_desktop_feature_div span.a-price-whole","#corePrice_desktop span.a-price-whole","#apex_desktop .priceToPay .a-offscreen","#apex_desktop .a-price .a-offscreen","#priceblock_dealprice","#priceblock_ourprice","#priceblock_saleprice","#price_inside_buybox","#newBuyBoxPrice",".priceToPay .a-offscreen","span.a-price.a-text-price.header-price .a-offscreen","span.a-price span.a-offscreen",".a-price.a-text-price .a-offscreen","span.a-price-whole","#price"];for(const d of t){const w=document.querySelector(d);if(w){const y=(w.textContent||w.innerText||"").trim();if(y){const $=_(y);if($>0){i=$;break}}}}}if(!i){const t=((h=document.querySelector('meta[property="og:price:amount"]'))==null?void 0:h.getAttribute("content"))||((b=document.querySelector('meta[name="twitter:data1"]'))==null?void 0:b.getAttribute("content"));t&&(i=_(t))}const u=["#corePriceDisplay_desktop_feature_div .basisPrice .a-offscreen","#corePrice_desktop .basisPrice .a-offscreen",".basisPrice .a-offscreen",'span[data-a-strike="true"]',".a-price.a-text-price .a-offscreen","#listPrice"];for(const t of u){const d=document.querySelector(t);if(d){const w=(d.textContent||d.innerText||"").trim();if(w){const y=_(w);if(y>i){s=y;break}}}}s||(s=i);const n=document.getElementById("availability"),p=((n==null?void 0:n.textContent)||(n==null?void 0:n.innerText)||"").toLowerCase();return(p.includes("currently unavailable")||p.includes("out of stock"))&&(l=!1),i<=0?null:{platform:"amazon",externalId:o,title:c.replace(/\s+/g," ").trim(),url:window.location.origin+"/dp/"+o,imageUrl:a,currentPrice:i,mrpPrice:s,currency:"INR",inStock:l}}function q(e){if(!e)return 0;const r=String(e).replace(/,/g,"").replace(/[^0-9.]/g," ").trim().match(/(\d+(?:\.\d+)?)/);return r?parseFloat(r[1]):0}function J(){var m;const e=window.location.href;let o="";const r=e.match(/[?&]pid=([A-Z0-9]+)/i);if(r)o=r[1];else{const f=e.match(/\/p\/(itm[a-zA-Z0-9]+)/i);f&&(o=f[1])}if(!o)return null;let c="",a="",i=0,s=0,l=!0;const g=document.querySelectorAll('script[type="application/ld+json"]');for(const f of g)try{const h=JSON.parse(f.innerText||"{}"),b=Array.isArray(h)?h:[h];for(const t of b)if(t["@type"]==="Product"&&(t.name&&(c=t.name),t.image&&(a=Array.isArray(t.image)?t.image[0]:t.image),t.offers)){const d=Array.isArray(t.offers)?t.offers[0]:t.offers;d.price&&(i=q(d.price))}}catch{}if(!c){const f=document.querySelector("span.B_NuCI, h1._6EBuvd, h1.VU-ZEz, span._35KyD6, h1");c=((m=f==null?void 0:f.innerText)==null?void 0:m.trim())||document.title}if(!a){const f=document.querySelector("img._396cs4, img._2r_T1I, img.DByuf4, img._3kidjx");a=(f==null?void 0:f.src)||""}if(!i){const f=["div.Nx9daj div._30jeq3","div._30jeq3._16Jk6d","div._30jeq3","div.hl05eU div._30jeq3"];for(const h of f){const b=document.querySelector(h);if(b&&b.innerText){const t=q(b.innerText);if(t>0){i=t;break}}}}const u=["div.yRaY8j","div._3I9_wc._2p6lqe","div._3I9_wc","div.hl05eU div._3I9_wc"];for(const f of u){const h=document.querySelector(f);if(h&&h.innerText){const b=q(h.innerText);if(b>i){s=b;break}}}s||(s=i);const n=document.querySelector("div._16FRp0, ._2SmN8-"),p=document.body.innerText.toLowerCase();return(n||p.includes("sold out")||p.includes("currently out of stock"))&&(l=!1),i<=0?null:{platform:"flipkart",externalId:o,title:c,url:e,imageUrl:a,currentPrice:i,mrpPrice:s,currency:"INR",inStock:l}}function j(e){if(!e)return 0;const r=String(e).replace(/,/g,"").replace(/[^0-9.]/g," ").trim().match(/(\d+(?:\.\d+)?)/);return r?parseFloat(r[1]):0}function H(){var f,h,b,t,d;const e=window.location.href,o=e.match(/\/([0-9]{5,10})(?:\/buy)?(?:[?#]|$)/i);if(!o)return null;const r=o[1];let c="",a="",i=0,s=0,l=!0;const g=((h=(f=document.querySelector("h1.pdp-title"))==null?void 0:f.innerText)==null?void 0:h.trim())||"",u=((t=(b=document.querySelector("h1.pdp-name"))==null?void 0:b.innerText)==null?void 0:t.trim())||"";c=g?`${g} ${u}`:u||document.title;const n=document.querySelector("div.image-grid-image, img.image-grid-image");n&&(a=n.getAttribute("src")||"",!a&&((d=n.style)!=null&&d.backgroundImage)&&(a=n.style.backgroundImage.replace(/^url\(["']?/,"").replace(/["']?\)$/,"")));const p=document.querySelector("span.pdp-price strong, span.pdp-discounted-price, span.pdp-price");p&&p.innerText&&(i=j(p.innerText));const m=document.querySelector("span.pdp-mrp s, span.pdp-mrp");if(m&&m.innerText){const w=j(m.innerText);w>i&&(s=w)}return s||(s=i),i<=0?null:{platform:"myntra",externalId:r,title:c,url:e,imageUrl:a,currentPrice:i,mrpPrice:s,currency:"INR",inStock:l}}function V(e){let o=window.location.href,r=null;const c=()=>{clearTimeout(r),r=setTimeout(()=>{const l=window.location.href;l!==o&&(o=l,e())},600)},a=history.pushState;history.pushState=function(...l){a.apply(this,l),c()};const i=history.replaceState;history.replaceState=function(...l){i.apply(this,l),c()},window.addEventListener("popstate",c);const s=new MutationObserver(()=>{window.location.href!==o&&c()});document.body?s.observe(document.body,{childList:!0,subtree:!0}):document.addEventListener("DOMContentLoaded",()=>{s.observe(document.body,{childList:!0,subtree:!0})})}let P=null,k=null,x=null,E=!1,C=!1,S=10,M=!1,T="";function F(e,o){if(!e||e<=0)return 0;const r=e*(1-o/100);return Math.round(r*100)/100}function A(e){return!e&&e!==0?"₹0":"₹"+Number(e).toLocaleString("en-IN")}async function X(e){var o;return!e||typeof chrome>"u"||!((o=chrome.storage)!=null&&o.local)?{isTracked:!1,token:null,trackingInfo:null}:new Promise(r=>{chrome.storage.local.get(["token","trackedKeys","defaultThreshold","user"],c=>{const a=c.token,i=`${e.platform}:${e.externalId}`,l=(c.trackedKeys||{})[i]||null;r({isTracked:!!l,token:a,trackingInfo:l,defaultThreshold:c.defaultThreshold||10,user:c.user||null})})})}async function Q(e,o,r){var s,l,g,u;const c={...e,targetPercentageDrop:r,baseline:"initial"};if(typeof chrome<"u"&&((s=chrome.runtime)!=null&&s.sendMessage))try{const n=await new Promise((p,m)=>{chrome.runtime.sendMessage({type:"TRACK_ITEM",payload:c,token:o},f=>{chrome.runtime.lastError?m(new Error(chrome.runtime.lastError.message)):p(f)})});if(n){if(n.success)return n.data;throw new Error(n.error||"Failed to track product.")}}catch(n){if((l=n.message)!=null&&l.includes("Extension context invalidated"))throw new Error("Price Ghost extension was reloaded. Please refresh this page.");console.warn("[Price Ghost] Service worker track failed, attempting direct fetch fallback:",n.message)}const a=[N,"https://price-ghost.netlify.app/api","https://price-ghost.onrender.com/api"];let i=null;for(const n of a)try{const p=await fetch(`${n.replace(/\/+$/,"")}/items/track`,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${o}`},body:JSON.stringify(c)}),m=await p.json().catch(()=>({}));if(p.ok)return typeof chrome<"u"&&((g=chrome.storage)!=null&&g.local)&&(chrome.storage.local.get(["trackedKeys"],f=>{var t,d;const h=f.trackedKeys||{},b=`${e.platform}:${e.externalId}`;h[b]={itemId:(t=m.item)==null?void 0:t._id,targetPercentageDrop:r,targetPrice:((d=m.tracking)==null?void 0:d.targetPrice)||F(e.currentPrice,r),baselinePrice:e.currentPrice,trackedAt:Date.now()},chrome.storage.local.set({trackedKeys:h})}),(u=chrome.runtime)!=null&&u.sendMessage&&chrome.runtime.sendMessage({type:"ITEM_TRACKED",payload:m}).catch(()=>{})),m;throw new Error(m.error||`Server responded with status ${p.status}`)}catch(p){i=p}throw i||new Error("Failed to connect to Price Ghost tracker service.")}async function ee(e,o,r){var a,i,s,l;if(typeof chrome<"u"&&((a=chrome.runtime)!=null&&a.sendMessage))try{const g=await new Promise((u,n)=>{chrome.runtime.sendMessage({type:"UNTRACK_ITEM",itemId:e,platform:o==null?void 0:o.platform,externalId:o==null?void 0:o.externalId,token:r},p=>{chrome.runtime.lastError?n(new Error(chrome.runtime.lastError.message)):u(p)})});if(g){if(g.success)return g.data;throw new Error(g.error||"Failed to untrack item.")}}catch(g){if((i=g.message)!=null&&i.includes("Extension context invalidated"))throw new Error("Price Ghost extension was reloaded. Please refresh this page.");console.warn("[Price Ghost] Service worker untrack failed, attempting direct fetch fallback:",g.message)}if(!(await fetch(`${N}/items/untrack/${e}`,{method:"DELETE",headers:{Authorization:`Bearer ${r}`}})).ok)throw new Error("Failed to untrack item.");typeof chrome<"u"&&((s=chrome.storage)!=null&&s.local)&&(chrome.storage.local.get(["trackedKeys"],g=>{const u=g.trackedKeys||{},n=`${o.platform}:${o.externalId}`;delete u[n],chrome.storage.local.set({trackedKeys:u})}),(l=chrome.runtime)!=null&&l.sendMessage&&chrome.runtime.sendMessage({type:"REFRESH_BADGE"}).catch(()=>{}))}const K=`
  :host {
    all: initial;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    font-size: 13px;
    line-height: 1.4;
    color: #1e293b;
    box-sizing: border-box;
    z-index: 2147483647;
    position: fixed;
    bottom: 24px;
    right: 24px;
    pointer-events: auto;
  }

  *, *::before, *::after {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }

  /* Floating Pill */
  .pg-floating-pill {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 18px;
    border-radius: 9999px;
    background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
    color: #ffffff;
    font-weight: 600;
    font-size: 13px;
    box-shadow: 0 10px 25px -5px rgba(79, 70, 229, 0.4), 0 8px 10px -6px rgba(79, 70, 229, 0.3);
    cursor: pointer;
    border: 1px solid rgba(255, 255, 255, 0.2);
    transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
    user-select: none;
    outline: none;
  }

  .pg-floating-pill:hover {
    transform: translateY(-2px) scale(1.02);
    box-shadow: 0 14px 28px -5px rgba(79, 70, 229, 0.5), 0 10px 12px -6px rgba(79, 70, 229, 0.4);
  }

  .pg-floating-pill.tracked {
    background: linear-gradient(135deg, #059669 0%, #10b981 100%);
    box-shadow: 0 10px 25px -5px rgba(16, 185, 129, 0.4), 0 8px 10px -6px rgba(16, 185, 129, 0.3);
  }

  .pg-ghost-icon {
    font-size: 16px;
    line-height: 1;
    filter: drop-shadow(0 1px 2px rgba(0, 0, 0, 0.2));
  }

  .pg-price-tag {
    background: rgba(255, 255, 255, 0.2);
    padding: 2px 8px;
    border-radius: 9999px;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: -0.01em;
  }

  .pg-min-toggle {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 18px;
    height: 18px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.2);
    font-size: 11px;
    margin-left: 2px;
    opacity: 0.7;
    transition: opacity 0.15s;
  }
  .pg-min-toggle:hover {
    opacity: 1;
    background: rgba(255, 255, 255, 0.35);
  }

  /* Minimized Bubble */
  .pg-bubble-minimized {
    width: 46px;
    height: 46px;
    border-radius: 50%;
    background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    box-shadow: 0 8px 20px rgba(79, 70, 229, 0.4);
    cursor: pointer;
    border: 2px solid white;
    transition: transform 0.2s;
  }
  .pg-bubble-minimized:hover {
    transform: scale(1.1);
  }

  /* Popover Card */
  .pg-card {
    position: absolute;
    bottom: 58px;
    right: 0;
    width: 325px;
    background: #ffffff;
    border-radius: 16px;
    box-shadow: 0 20px 40px -10px rgba(0, 0, 0, 0.22), 0 0 0 1px rgba(0, 0, 0, 0.06);
    overflow: hidden;
    animation: pgSlideUp 0.25s cubic-bezier(0.16, 1, 0.3, 1);
  }

  @keyframes pgSlideUp {
    from {
      opacity: 0;
      transform: translateY(12px) scale(0.97);
    }
    to {
      opacity: 1;
      transform: translateY(0) scale(1);
    }
  }

  .pg-card-header {
    background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
    padding: 12px 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid #e2e8f0;
  }

  .pg-brand {
    display: flex;
    align-items: center;
    gap: 6px;
    font-weight: 700;
    font-size: 13px;
    color: #1e293b;
  }

  .pg-platform-pill {
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    padding: 2px 6px;
    border-radius: 4px;
    background: #e0e7ff;
    color: #4338ca;
  }

  .pg-close-btn {
    background: transparent;
    border: none;
    color: #94a3b8;
    font-size: 16px;
    cursor: pointer;
    line-height: 1;
    padding: 4px;
    border-radius: 4px;
  }
  .pg-close-btn:hover {
    color: #475569;
    background: #e2e8f0;
  }

  .pg-card-body {
    padding: 16px;
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .pg-prod-title {
    font-size: 12px;
    font-weight: 600;
    color: #0f172a;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    line-height: 1.35;
  }

  .pg-price-row {
    display: flex;
    align-items: baseline;
    gap: 8px;
  }

  .pg-current-price {
    font-size: 18px;
    font-weight: 800;
    color: #4f46e5;
  }

  .pg-mrp-price {
    font-size: 12px;
    color: #94a3b8;
    text-decoration: line-through;
  }

  .pg-section-label {
    font-size: 11px;
    font-weight: 600;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.03em;
  }

  .pg-threshold-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 6px;
  }

  .pg-thresh-btn {
    padding: 6px 0;
    border-radius: 8px;
    border: 1px solid #e2e8f0;
    background: #ffffff;
    font-size: 12px;
    font-weight: 600;
    color: #475569;
    cursor: pointer;
    transition: all 0.15s;
    text-align: center;
  }

  .pg-thresh-btn:hover {
    border-color: #cbd5e1;
    background: #f8fafc;
  }

  .pg-thresh-btn.active {
    border-color: #4f46e5;
    background: #eef2ff;
    color: #4f46e5;
    font-weight: 700;
  }

  .pg-slider-wrap {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .pg-range-input {
    flex: 1;
    accent-color: #4f46e5;
    cursor: pointer;
  }

  .pg-target-box {
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    padding: 10px;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .pg-target-title {
    font-size: 11px;
    color: #64748b;
  }

  .pg-target-price {
    font-size: 14px;
    font-weight: 800;
    color: #059669;
  }

  .pg-action-btn {
    width: 100%;
    padding: 11px;
    border-radius: 10px;
    border: none;
    background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%);
    color: white;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
    transition: all 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 6px;
  }

  .pg-action-btn:hover {
    box-shadow: 0 6px 16px rgba(79, 70, 229, 0.4);
    filter: brightness(1.05);
  }

  .pg-action-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }

  .pg-btn-danger {
    background: #fee2e2;
    color: #b91c1c;
    border: 1px solid #fecaca;
    padding: 8px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    width: 100%;
    transition: background 0.15s;
  }
  .pg-btn-danger:hover {
    background: #fecaca;
  }

  .pg-status-banner {
    padding: 8px 12px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    text-align: center;
  }

  .pg-status-banner.success {
    background: #ecfdf5;
    color: #065f46;
    border: 1px solid #a7f3d0;
  }

  .pg-status-banner.error {
    background: #fef2f2;
    color: #991b1b;
    border: 1px solid #fecaca;
  }
`;async function v(){var n;if(!k||!x)return;const{isTracked:e,token:o,trackingInfo:r,defaultThreshold:c,user:a}=await X(x);if(C){k.innerHTML=`
      <style>${K}</style>
      <div class="pg-bubble-minimized" title="Price Ghost — Click to expand">
        👻
      </div>
    `,(n=k.querySelector(".pg-bubble-minimized"))==null||n.addEventListener("click",()=>{C=!1,v()});return}const i=A(x.currentPrice),s=F(x.currentPrice,S),l=x.currentPrice-s,g=e?`Tracked (-${(r==null?void 0:r.targetPercentageDrop)||10}%)`:"Track Price",u=`
    <style>${K}</style>

    ${E?`
      <div class="pg-card">
        <div class="pg-card-header">
          <div class="pg-brand">
            <span>👻</span>
            <span>Price Ghost</span>
            <span class="pg-platform-pill">${x.platform}</span>
          </div>
          <button class="pg-close-btn" id="pg-card-close" title="Close">✕</button>
        </div>

        <div class="pg-card-body">
          <p class="pg-prod-title" title="${x.title}">
            ${x.title}
          </p>

          <div class="pg-price-row">
            <span class="pg-current-price">${i}</span>
            ${x.mrpPrice&&x.mrpPrice>x.currentPrice?`<span class="pg-mrp-price">${A(x.mrpPrice)}</span>`:""}
          </div>

          ${T?`<div class="pg-status-banner ${T.type}">${T.text}</div>`:""}

          ${o?e?`
            <div style="padding: 12px; background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 10px;">
              <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
                <span style="font-size: 12px; font-weight: 700; color: #065f46;">
                  Currently Monitored
                </span>
                <span style="font-size: 11px; font-weight: 700; color: #059669; background: #d1fae5; padding: 2px 6px; border-radius: 4px;">
                  -${(r==null?void 0:r.targetPercentageDrop)||10}% Target
                </span>
              </div>
              <p style="font-size: 11px; color: #047857;">
                Alert Price: <strong>${A((r==null?void 0:r.targetPrice)||s)}</strong>
              </p>
            </div>

            <div style="display: flex; gap: 8px; margin-top: 4px;">
              <button id="pg-untrack-btn" class="pg-btn-danger">
                Remove from Tracking
              </button>
            </div>
            `:`
            <div>
              <span class="pg-section-label">Alert me when price drops by:</span>
              <div class="pg-threshold-grid" style="margin-top: 6px; margin-bottom: 8px;">
                ${[5,10,15,20].map(p=>`
                  <button class="pg-thresh-btn ${S===p?"active":""}" data-pct="${p}">
                    ${p}%
                  </button>
                `).join("")}
              </div>

              <div class="pg-slider-wrap">
                <input
                  type="range"
                  id="pg-thresh-slider"
                  class="pg-range-input"
                  min="1"
                  max="90"
                  value="${S}"
                />
                <span style="font-size: 12px; font-weight: 800; color: #4f46e5; width: 32px; text-align: right;">
                  ${S}%
                </span>
              </div>
            </div>

            <div class="pg-target-box">
              <div>
                <p class="pg-target-title">Notify below</p>
                <p class="pg-target-price">${A(s)}</p>
              </div>
              <div style="text-align: right;">
                <p class="pg-target-title">You Save</p>
                <p style="font-size: 12px; font-weight: 700; color: #4f46e5;">${A(l)}</p>
              </div>
            </div>

            <button id="pg-track-submit" class="pg-action-btn" ${M?"disabled":""}>
              ${M?"Activating Tracker...":"👻 Track This Product"}
            </button>
            `:`
            <div style="padding: 12px; background: #fffbeb; border: 1px solid #fef3c7; border-radius: 10px; text-align: center;">
              <p style="font-size: 12px; color: #92400e; font-weight: 600; margin-bottom: 8px;">
                Sign in to track price drops!
              </p>
              <p style="font-size: 11px; color: #b45309; margin-bottom: 10px;">
                Connect Price Ghost to receive email alerts when this item's price falls.
              </p>
              <button id="pg-open-dashboard" class="pg-action-btn" style="font-size: 12px; padding: 8px;">
                Open Price Ghost Dashboard →
              </button>
            </div>
            `}
        </div>
      </div>
    `:""}

    <div class="pg-floating-pill ${e?"tracked":""}" id="pg-pill-btn">
      <span class="pg-ghost-icon">${e?"✓":"👻"}</span>
      <span>${g}</span>
      <span class="pg-price-tag">${i}</span>
      <span class="pg-min-toggle" id="pg-min-btn" title="Minimize">−</span>
    </div>
  `;k.innerHTML=u,te(o,e,r)}function te(e,o,r){var c,a,i,s,l,g,u;k&&((c=k.querySelector("#pg-pill-btn"))==null||c.addEventListener("click",n=>{n.target.closest("#pg-min-btn")||(E=!E,T="",v())}),(a=k.querySelector("#pg-min-btn"))==null||a.addEventListener("click",n=>{n.stopPropagation(),C=!0,E=!1,v()}),(i=k.querySelector("#pg-card-close"))==null||i.addEventListener("click",()=>{E=!1,T="",v()}),(s=k.querySelector("#pg-open-dashboard"))==null||s.addEventListener("click",()=>{window.open(`${Z}/dashboard`,"_blank")}),k.querySelectorAll(".pg-thresh-btn").forEach(n=>{n.addEventListener("click",()=>{S=Number(n.getAttribute("data-pct")),v()})}),(l=k.querySelector("#pg-thresh-slider"))==null||l.addEventListener("input",n=>{S=Number(n.target.value),v()}),(g=k.querySelector("#pg-track-submit"))==null||g.addEventListener("click",async()=>{if(!(!x||!e)){M=!0,T="",v();try{await Q(x,e,S),T={type:"success",text:`🎉 Price tracker set for -${S}% drop!`},setTimeout(()=>{E=!1,v()},2e3)}catch(n){T={type:"error",text:n.message||"Failed to track product."}}finally{M=!1,v()}}}),(u=k.querySelector("#pg-untrack-btn"))==null||u.addEventListener("click",async()=>{if(!(!(r!=null&&r.itemId)||!e)&&confirm("Stop tracking this product?"))try{await ee(r.itemId,x,e),T={type:"success",text:"Product removed from tracking."},setTimeout(()=>{E=!1,v()},1500)}catch(n){alert("Failed to untrack: "+n.message)}}))}function B(e){if(!e||!e.externalId||e.currentPrice<=0){W();return}x=e,P||(P=document.createElement("div"),P.id="price-ghost-extension-root",k=P.attachShadow({mode:"open"}),document.documentElement.appendChild(P)),v()}function W(){P&&P.parentNode&&P.parentNode.removeChild(P),P=null,k=null,x=null}function z(){const e=window.location.hostname;return e.includes("amazon.")?Y():e.includes("flipkart.")?J():e.includes("myntra.")?H():null}let D=null,I=0;const re=6,oe=[500,1200,2500,4e3,6e3,9e3];async function ne(e,o,r){var c,a,i,s;try{const l={...e,targetPercentageDrop:r||10,baseline:"initial"};if(console.log(`[Price Ghost] 🚀 Sending manual track request for "${e.title}"...`),typeof chrome<"u"&&((c=chrome.runtime)!=null&&c.sendMessage))try{const u=await new Promise((n,p)=>{chrome.runtime.sendMessage({type:"TRACK_ITEM",payload:l,token:o},m=>{chrome.runtime.lastError?p(new Error(chrome.runtime.lastError.message)):n(m)})});if(u!=null&&u.success)return console.log("[Price Ghost] 👻 Tracked product successfully via Service Worker:",e.title),!0}catch(u){console.warn("[Price Ghost] Service worker track message failed, falling back to direct fetch:",u.message)}const g=[N,"https://price-ghost.netlify.app/api","https://price-ghost.onrender.com/api"];for(const u of g)try{const n=await fetch(`${u.replace(/\/+$/,"")}/items/track`,{method:"POST",headers:{"Content-Type":"application/json","X-Client-Type":"extension",Authorization:`Bearer ${o}`},body:JSON.stringify(l)});if(n.ok){const p=await n.json();return console.log("[Price Ghost] 👻 Tracked product successfully:",((a=p.item)==null?void 0:a.title)||e.title),typeof chrome<"u"&&((i=chrome.storage)!=null&&i.local)&&chrome.storage.local.get(["trackedKeys"],m=>{var b;const f=m.trackedKeys||{},h=`${e.platform}:${e.externalId}`;f[h]={itemId:(b=p.item)==null?void 0:b._id,targetPercentageDrop:r||10,trackedAt:Date.now()},chrome.storage.local.set({trackedKeys:f})}),typeof chrome<"u"&&((s=chrome.runtime)!=null&&s.sendMessage)&&chrome.runtime.sendMessage({type:"ITEM_TRACKED",payload:p}).catch(()=>{}),!0}}catch{}return!1}catch(l){return console.warn("[Price Ghost] Backend connection error:",l.message),!1}}async function R(){var o;const e=z();if(!e||!e.externalId||e.currentPrice<=0){if(I<re){const r=oe[I]||2e3;I++,clearTimeout(D),D=setTimeout(R,r)}else W();return}`${e.platform}${e.externalId}`,typeof chrome<"u"&&((o=chrome.storage)!=null&&o.local)&&chrome.storage.local.set({lastSeenProduct:{...e,detectedAt:Date.now()}}),console.log(`[Price Ghost] 🎯 Detected ${e.platform} product: "${e.title}" @ ₹${e.currentPrice}`),B(e)}function L(){I=0,clearTimeout(D),R()}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{L()}):L();V(()=>{L()});let U=null;const ie=new MutationObserver(()=>{clearTimeout(U),U=setTimeout(()=>{R()},1e3)}),G=document.body||document.documentElement;G&&ie.observe(G,{childList:!0,subtree:!0});var O;typeof chrome<"u"&&((O=chrome.runtime)!=null&&O.onMessage)&&chrome.runtime.onMessage.addListener((e,o,r)=>{var c;if(e.type==="GET_PAGE_PRODUCT"){const a=z();r({product:a})}else if(e.type==="REFRESH_PAGE_BUTTON"||e.type==="ITEM_TRACKED"){const a=z();a&&B(a),r({updated:!0})}else if(e.type==="FORCE_TRACK_PAGE"){const a=z();return a&&a.currentPrice>0?(c=chrome.storage)!=null&&c.local&&chrome.storage.local.get(["token","defaultThreshold"],async i=>{if(i.token){const s=e.targetPercentageDrop||i.defaultThreshold||10,l=await ne(a,i.token,s);l&&B(a),r({success:l,product:a})}else r({success:!1,error:"Not logged in"})}):r({success:!1,error:"Could not extract product details"}),!0}});
